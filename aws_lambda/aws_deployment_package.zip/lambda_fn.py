"""
Daily stock update to database

This lambda function will call the API when the stock market closes, and add
today's data into the AWS RDS database. 

Lambda function is scheduled every Mon-Fri at 5:30 PM using AWS CloudWatch.
CloudWatch is scheduled using cron expression: cron(30 17 ? * MON-FRI *)

***Note!

When uploading a deployement package zip to AWS Lambda, you must use a custom
compiled psycopg2 library for psycopg2 to work. Link to a working library below:

https://github.com/jkehler/awslambda-psycopg2
"""

from botocore.vendored import requests
import psycopg2
import os
from datetime import datetime, timedelta

def load_todays_stocks(event=None, context=None):

	#Connect to API and get data after market closes
	url = 'https://financialmodelingprep.com/api/v3/historical-price-full/AAPL,GOOG,FB'
	param = {'timeseries' : '1'}
	resp = requests.get(url = url, params = param)

	#Make sure there is a proper connection to API
	if resp.ok:
		data = resp.json()['historicalStockList']

		dbname = 'postgres'
		user = 'postgres'
		host = os.environ.get('aws_host')
		port = 5432
		pw = os.environ.get('aws_pw')
		try:
			con = psycopg2.connect(dbname = dbname, 
								   user = user, 
								   host = host, 
								   port = port,
								   password = pw)
		except:
			print('Connection to Database Error')
		else:
			cur = con.cursor()
			try:
				#For every symbol (AAPL, GOOGL, FB)
				for item in data:
					symbol = item['symbol']
					rows = item['historical']
					#For every row corresponding to a day
					for row in rows:
						my_data = [symbol] + [row[field] for field in row]
						#Only insert first seven elements
						my_data = my_data[:7]
						#Get previous day's close value to calculate percent_change
						previous_day = datetime.strptime(my_data[1], '%Y-%m-%d') - \
									   timedelta(days = 1)
						cur.execute("""SELECT closed
										FROM stocks
										WHERE symbol = %s
										AND open_day = %s
									""", (my_data[0], previous_day))
						#Check if there is data to calculate percent_change
						#If there is no data from previous day, percent_change will be NULL
						if cur.fetchone():
							yesterday_closed = cur.fetchone()[0]
							todays_closed = my_data[5]
							percent_change = (todays_closed - yesterday_closed) /  \
											  todays_closed * 100
							my_data.append(percent_change)
							cur.execute("INSERT INTO stocks VALUES \
										(%s, %s, %s, %s, %s, %s, %s, %s)", tuple(my_data))
						else:
							cur.execute("INSERT INTO stocks VALUES \
										(%s, %s, %s, %s, %s, %s, %s)", tuple(my_data))
				con.commit()
			except psycopg2.DatabaseError as error:
				print(error)
			finally:
				if con is not None:
					con.close()
	else:
		print('Connection Error')