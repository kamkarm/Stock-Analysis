"""
Daily stock update to database

This lambda function will call the API when the stock market closes, and add
today's data into the AWS RDS database. 

Lambda function is scheduled every Mon-Fri at 5:30 PM using AWS CloudWatch.
CloudWatch is scheduled using cron expression: cron(30 21 ? * MON-FRI *)

***Note!

When uploading a deployement package zip to AWS Lambda, you must use a custom
compiled psycopg2 library for psycopg2 to work. Link to a working library below:

https://github.com/jkehler/awslambda-psycopg2
"""

import psycopg2
from fetch_data import fetch_todays_data
from insert_data import insert

def load_todays_stocks(event=None, context=None):

	data = fetch_todays_data()
	if data:
		insert(data)