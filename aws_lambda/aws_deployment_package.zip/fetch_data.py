"""
Returns Apple's, Google's, and Facebook's stocks from today

Data is acquired through the Financial Modeling Prep API
"""

from botocore.vendored import requests

def fetch_todays_data():

	#Connect to API and get data after market closes
	url = 'https://financialmodelingprep.com/api/v3/historical-price-full/AAPL,GOOG,FB'
	param = {'timeseries' : '1'}
	resp = requests.get(url = url, params = param)
	data = None
	#Make sure there is a proper connection to API
	if resp.ok:
		data = resp.json()['historicalStockList']
	else:
		print('Connection to API Failed')
	return data