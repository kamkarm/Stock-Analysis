"""
Inserts data into AWS rds database

Input: Json data from Financial Modeling Prep API
"""

import psycopg2
from datetime import datetime, timedelta
import db

def insert(data):

	con = db.connect()
	cur = con.cursor()
	try:
		#For every symbol (AAPL, GOOGL, FB)
		for item in data:
			symbol = item['symbol']
			rows = item['historical']
			#For every row corresponding to a day
			for row in rows:
				my_data = [symbol] + [row[field] for field in row]
				#Only insert first seven elements
				my_data = my_data[:7]
				#Get previous day's close value to calculate percent_change
				#If today is Monday, get Friday's close value
				today = datetime.strptime(my_data[1], '%Y-%m-%d')
				if today.weekday() == 0:
					previous_day = today - timedelta(days = 3)
				else:
					previous_day = today - timedelta(days = 1)		   
				cur.execute("""SELECT closed
								FROM stocks
								WHERE symbol = %s
								AND open_day = %s
							""", (my_data[0], previous_day))
				#Check if there is data to calculate percent_change
				#If there is no data from previous day, percent_change will be NULL
				yesterday_closed = cur.fetchone()
				if yesterday_closed:
					yesterday_closed = yesterday_closed[0]
					todays_closed = my_data[5]
					percent_change = (todays_closed - yesterday_closed) /  \
									  todays_closed * 100
					my_data.append(percent_change)
					cur.execute("INSERT INTO stocks VALUES \
								(%s, %s, %s, %s, %s, %s, %s, %s)", tuple(my_data))
				else:
					cur.execute("INSERT INTO stocks VALUES \
								(%s, %s, %s, %s, %s, %s, %s)", tuple(my_data))
		con.commit()
	except psycopg2.DatabaseError as error:
		print(error)
	finally:
		if con is not None:
			con.close()